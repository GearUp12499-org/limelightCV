# FTC24-25_IntoTheDeep > 2024-10-05 5:29am
https://universe.roboflow.com/noah-fang/ftc24-25_intothedeep

Provided by a Roboflow user
License: MIT

